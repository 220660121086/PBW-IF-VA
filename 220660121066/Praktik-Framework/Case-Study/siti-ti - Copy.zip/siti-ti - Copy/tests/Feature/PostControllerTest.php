<?php

namespace Tests\Feature;

use App\Models\Post;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class PostControllerTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    use RefreshDatabase;

    /** @test */
   /** @test */
   public function test_it_can_delete_a_post()
   {
       // Create a post using a factory
       $post = Post::factory()->create();
   
       // Send a DELETE request to delete the post
       $response = $this->delete(route('posts.destroy', $post));
   
       // Ensure the post is removed from the database
       $this->assertDatabaseMissing('posts', ['id' => $post->id]);
   
       // Ensure redirection to the previous page
       $response->assertRedirect();
   }   

}

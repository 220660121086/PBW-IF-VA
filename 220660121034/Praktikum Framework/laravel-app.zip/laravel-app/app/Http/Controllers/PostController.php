<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;
use Inertia\Inertia;

class PostController extends Controller
{
    /**
     * Menampilkan daftar semua post.
     *
     * @return \Inertia\Response
     */
    public function index()
    {
        $posts = Post::all();
        return Inertia::render('Post/Index', ['posts' => $posts]);
    }
    

    /**
     * Menampilkan form untuk membuat post baru.
     *
     * @return \Inertia\Response
     */
    public function create()
    {
        // Menggunakan Inertia untuk merender tampilan 'Post/Create' untuk membuat post baru
        return Inertia::render('Post/Create');
    }

    /**
     * Menyimpan post baru ke dalam database.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
{
    // Validasi input
    $validated = $request->validate([
        'title' => 'required|max:255',
        'body' => 'required',
    ]);

    // Simpan data post ke dalam database
    Post::create($validated);

    // Redirect ke halaman index setelah berhasil disimpan
    return redirect()->route('posts.index');
}


    /**
     * Menampilkan form untuk mengedit post yang ada.
     *
     * @param \App\Models\Post $post
     * @return \Inertia\Response
     */
    public function edit(Post $post)
    {
        // Menggunakan Inertia untuk merender tampilan 'Post/Edit' dan mengirimkan data post yang ingin diedit
        return Inertia::render('Post/Edit', ['post' => $post]);
    }

    /**
     * Memperbarui post yang ada di database.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Post $post
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Post $post)
{
    // Validasi input data
    $validated = $request->validate([
        'title' => 'required|max:255',
        'body' => 'required',
    ]);

    // Memperbarui post
    $post->update($validated);

    // Redirect setelah berhasil memperbarui post
    return redirect()->route('posts.index');
}


    /**
     * Menghapus post dari database.
     *
     * @param \App\Models\Post $post
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Post $post)
    {
        // Menghapus post yang dipilih dari database
        $post->delete();

        // Mengarahkan pengguna kembali ke halaman sebelumnya (biasanya daftar post)
        return redirect()->route('posts.index');
    }
}
